import { login, logout, getUserInfo } from '@/api/user'

const state = {
  token: localStorage.getItem('token'),
  user: null
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_USER: (state, user) => {
    state.user = user
  }
}

const actions = {
  // 登录
  async login({ commit }, userInfo) {
    try {
      const { data } = await login(userInfo)
      commit('SET_TOKEN', data.token)
      commit('SET_USER', data.user)
      localStorage.setItem('token', data.token)
      return data
    } catch (error) {
      throw error
    }
  },

  // 登出
  async logout({ commit }) {
    try {
      await logout()
      commit('SET_TOKEN', '')
      commit('SET_USER', null)
      localStorage.removeItem('token')
    } catch (error) {
      throw error
    }
  },

  // 获取用户信息
  async getUserInfo({ commit }) {
    try {
      const { data } = await getUserInfo()
      commit('SET_USER', data)
      return data
    } catch (error) {
      throw error
    }
  }
}

const getters = {
  isAuthenticated: state => !!state.token,
  userInfo: state => state.user
}

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters
} 