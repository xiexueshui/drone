import request from './request'

export function uploadFile(file) {
  const formData = new FormData()
  formData.append('file', file)
  return request({
    url: '/media/upload',
    method: 'post',
    data: formData
  })
}

export function tagMedia(data) {
  return request({
    url: '/media/tag',
    method: 'post',
    data
  })
}

export function cutVideo(data) {
  return request({
    url: '/media/video/cut',
    method: 'post',
    data
  })
} 