import request from '@/utils/request'

/**
 * 用户登录
 * @param {Object} data 登录信息
 * @param {string} data.username 用户名
 * @param {string} data.password 密码
 * @returns {Promise} 返回登录结果
 */
export function login(data) {
  return request({
    url: '/api/users/login',
    method: 'post',
    data,
    // 登录接口不需要带Authorization头
    headers: {
      'Content-Type': 'application/json',
      'Authorization': undefined
    }
  })
}

/**
 * 获取用户信息
 * @returns {Promise} 返回用户信息
 */
export function getUserInfo() {
  return request({
    url: '/api/users/info',
    method: 'get'
  })
}

/**
 * 退出登录
 * @returns {Promise}
 */
export function logout() {
  return request({
    url: '/api/users/logout',
    method: 'post'
  })
} 