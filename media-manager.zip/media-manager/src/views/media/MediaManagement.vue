<template>
  <div class="media-container">
    <el-container>
      <el-header>
        <el-button type="primary" @click="handleUpload">上传文件</el-button>
      </el-header>
      
      <el-main>
        <!-- 图片列表 -->
        <div class="image-list">
          <h3>图片列表</h3>
          <el-table :data="imageList">
            <el-table-column prop="name" label="图片名称"></el-table-column>
            <el-table-column prop="tags" label="标签"></el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button @click="handleTag(scope.row)">标注</el-button>
                <el-button @click="handleDownload(scope.row)">下载</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>

        <!-- 视频列表 -->
        <div class="video-list">
          <h3>视频列表</h3>
          <el-table :data="videoList">
            <el-table-column prop="name" label="视频名称"></el-table-column>
            <el-table-column prop="tags" label="标签"></el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button @click="handleCut(scope.row)">剪切</el-button>
                <el-button @click="handleTag(scope.row)">标注</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-main>
    </el-container>

    <!-- 上传文件对话框 -->
    <el-dialog title="上传文件" :visible.sync="uploadDialogVisible">
      <el-upload
        class="upload-demo"
        drag
        action="/api/media/upload"
        :headers="uploadHeaders"
        :on-success="handleUploadSuccess"
        :on-error="handleUploadError"
      >
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
      </el-upload>
    </el-dialog>

    <!-- 标注对话框 -->
    <el-dialog title="添加标注" :visible.sync="tagDialogVisible">
      <el-form :model="tagForm">
        <el-form-item label="标签名称">
          <el-input v-model="tagForm.tagName"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="tagDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitTag">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { tagMedia } from '@/api/media'

export default {
  name: 'MediaManagement',
  data() {
    return {
      imageList: [],
      videoList: [],
      uploadDialogVisible: false,
      tagDialogVisible: false,
      currentMedia: null,
      tagForm: {
        tagName: ''
      },
      uploadHeaders: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    }
  },
  methods: {
    handleUpload() {
      this.uploadDialogVisible = true
    },
    handleTag(media) {
      this.currentMedia = media
      this.tagDialogVisible = true
    },
    handleDownload(media) {
      window.open(media.fileUrl, '_blank')
    },
    handleCut(media) {
      // TODO: 实现视频剪切逻辑
      console.log('剪切视频:', media)
    },
    async submitTag() {
      try {
        await tagMedia({
          mediaId: this.currentMedia.id,
          tagName: this.tagForm.tagName
        })
        this.$message.success('标注成功')
        this.tagDialogVisible = false
        this.loadMediaList()
      } catch (error) {
        this.$message.error('标注失败')
      }
    },
    handleUploadSuccess() {
      this.$message.success('上传成功')
      this.uploadDialogVisible = false
      this.loadMediaList()
    },
    handleUploadError() {
      this.$message.error('上传失败')
    },
    async loadMediaList() {
      // TODO: 实现加载媒体列表的逻辑
      this.imageList = []
      this.videoList = []
    }
  },
  created() {
    this.loadMediaList()
  }
}
</script>

<style scoped>
.media-container {
  padding: 20px;
}

.image-list, .video-list {
  margin-bottom: 30px;
}

.el-header {
  padding: 0;
  margin-bottom: 20px;
}
</style> 