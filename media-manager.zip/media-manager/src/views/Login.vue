<template>
  <div class="login-container">
    <div class="login-box">
      <div class="login-header">
        <img src="@/assets/drone.png" alt="drone" class="logo">
        <h2>无人机数据管理平台</h2>
      </div>
      <el-form 
        :model="loginForm" 
        :rules="loginRules" 
        ref="loginForm" 
        class="login-form"
      >
        <el-form-item prop="username">
          <el-input 
            v-model="loginForm.username" 
            prefix-icon="el-icon-user" 
            placeholder="请输入用户名">
          </el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input 
            v-model="loginForm.password" 
            prefix-icon="el-icon-lock" 
            type="password" 
            placeholder="请输入密码"
            @keyup.enter.native="handleLogin">
          </el-input>
        </el-form-item>
        <el-form-item>
          <el-button 
            type="primary" 
            class="login-button" 
            :loading="loading"
            @click="handleLogin">
            {{ loading ? '登录中...' : '登 录' }}
          </el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="login-footer">
      <p>Copyright © 2024 无人机数据管理平台</p>
    </div>
  </div>
</template>

<script>
import { login } from '@/api/user'
import { mapMutations } from 'vuex'

export default {
  name: 'Login',
  data() {
    return {
      loading: false,
      loginForm: {
        username: '',
        password: ''
      },
      loginRules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, max: 20, message: '长度在 6 到 20 个字符', trigger: 'blur' }
        ]
      }
    }
  },
  created() {
    // 如果已登录,直接跳转到首页
    if (this.$store.getters.isAuthenticated) {
      this.$router.push('/media')
    }
  },
  methods: {
    ...mapMutations(['SET_TOKEN', 'SET_USER']),
    
    async handleLogin() {
      try {
        await this.$refs.loginForm.validate()
        
        this.loading = true
        const { data } = await login({
          username: this.loginForm.username,
          password: this.loginForm.password
        })
        
        // 存储token到vuex和localStorage
        this.SET_TOKEN(data.token)
        localStorage.setItem('token', data.token)
        
        // 存储用户信息
        this.SET_USER(data.user)
        
        this.$message({
          message: '登录成功',
          type: 'success',
          duration: 2000
        })
        
        // 跳转到首页或者之前要访问的页面
        const redirect = this.$route.query.redirect || '/media'
        this.$router.push(redirect)
      } catch (error) {
        this.$message({
          type: 'error',
          message: error.response?.data?.message || '登录失败，请检查用户名和密码',
          duration: 2000
        })
      } finally {
        this.loading = false
      }
    }
  }
}
</script>

<style scoped>
.login-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background: linear-gradient(135deg, #1c2c4c 0%, #2c3e50 100%);
  position: relative;
  overflow: hidden;
}

.login-container::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image: url('~@/assets/drone-bg.jpg');
  background-size: cover;
  background-position: center;
  opacity: 0.1;
  z-index: 0;
}

.login-box {
  width: 400px;
  padding: 40px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  position: relative;
  z-index: 1;
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.logo {
  width: 80px;
  height: 80px;
  margin-bottom: 15px;
}

.login-header h2 {
  color: #2c3e50;
  font-size: 24px;
  margin: 0;
}

.login-form {
  margin-top: 20px;
}

.login-button {
  width: 100%;
  padding: 12px 0;
  font-size: 16px;
}

.el-input {
  margin-bottom: 5px;
}

.el-input /deep/ .el-input__inner {
  height: 45px;
  line-height: 45px;
}

.login-footer {
  position: absolute;
  bottom: 20px;
  color: rgba(255, 255, 255, 0.7);
  font-size: 14px;
  z-index: 1;
}

/* 添加响应式设计 */
@media screen and (max-width: 480px) {
  .login-box {
    width: 90%;
    padding: 20px;
  }
}
</style> 